var isExist = false;
function navshoppingcart() {
    var commodity1 = getCookie("delete1");
    var commodity2 = getCookie("delete2");
    var commodity3 = getCookie("delete3");
    var ul = document.getElementById("shopping-cart-box");
    checkcookies3("commodity");
    ul.innerHTML = "";
    if(commodity1 == ""){
        var newli1 = document.createElement("li");
        newli1.innerHTML = '<p><img src="/Art%20Store/src/images/works/shop1.jpg"><span>Still Life with Bowl and Fruit</span><br><span>$120.0000</span></p>';
        ul.appendChild(newli1);
    }
    //写/src/images/works/shop1.jpg没有黄色 但也不行 写成images/works/shop1.jpg 完全不行
    if(commodity2 == ""){
        var newli2 = document.createElement("li");
        newli2.innerHTML = '<p><img src="/Art%20Store/src/images/works/shop2tiny.jpg"><span>Family of Sanltimbanques</span><br><span>$170.0000</span></p>';
        ul.appendChild(newli2);
    }
    if((commodity3 == "")&&(isExist)){
        var newli3 = document.createElement("li");
        newli3.innerHTML = '<p><img src="/Art%20Store/src/images/works/mother-and-child-1922-1.jpg!Large.jpg"><span>Mother and Child(Olga and Son)</span><br><span>$100.0000</span></p>'
        ul.appendChild(newli3);
    }
    if ((commodity1!="")&&(commodity2 !="")&&((commodity3 !="")||!isExist)){
        var newli4 = document.createElement("li");
        newli4.innerHTML = '<p>还什么都没有哦~</p>';
        ul.appendChild(newli4);
    }
}

function getCookie(cname) {
    var name = cname + "=";
    var ca = document.cookie.split(';');
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i].trim();
        if (c.indexOf(name) == 0) return c.substring(name.length, c.length);
    }
    return "";
}


function checkcookies3(name) {
    var cookiesneed = getCookie(name);
    if (cookiesneed != "") {
        isExist = true;
    }
    else {
        isExist = false;
    }
}
