function showUp(){
    document.getElementById("fade").style.display='block';
    document.getElementById("recharge").style.display='block';
}
function recharge() {
    var money = document.getElementById("input").value;
    var total = document.getElementById("wallet").innerText;
    if (money === "") {
        alert("请输入充值金额！");
    }
    if (parseInt(money) < 0) {
        alert("本网站不倒贴钱");
    } else if (parseInt(money) >= 0) {
        document.getElementById("wallet").innerText = parseInt(total) + parseInt(money);
        alert("充值成功(●ˇ∀ˇ●)");
        money.value="";
        closeDiv();
    }
}
function closeDiv(){
    document.getElementById("fade").style.display='none';
    document.getElementById("recharge").style.display='none';
}