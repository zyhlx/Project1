function ontimecheckname() {
    var n = document.getElementById('name').value;
    if (n.length <= 0) {
        document.getElementById("forname").innerHTML="<font color='red'>用户名不能为空</font>";
    }
    else if (!is_user_name(n)) {
        document.getElementById("forname").innerHTML="<font color='red'>用户名不正确</font>";
    }else {
        document.getElementById("forname").innerHTML="<font color='red'> </font>";
    }
}

function ontimecheckpassword() {
    var n = document.getElementById('name').value;
    var p = document.getElementById('password').value;
    if (p.length <= 0) {
        document.getElementById("forpassword").innerHTML="<font color='red'>密码不能为空</font>";
    } else if (!is_psd(p)) {
        document.getElementById("forpassword").innerHTML="<font color='red'>密码格式不正确</font>";
    } else if (n === p) {
        document.getElementById("forpassword").innerHTML="<font color='red'>密码不能与用户名相同</font>";
    }else {
        document.getElementById("forpassword").innerHTML="<font color='red'> </font>";
    }
}
function ontimecheckpassword2() {
    var p = document.getElementById('password').value;
    var p2 = document.getElementById('check').value;
    if (p != p2) {
        document.getElementById("forpassword2").innerHTML="<font color='red'>密码不相等</font>";
    }else {
        document.getElementById("forpassword2").innerHTML="<font color='red'> </font>";
    }
}
function ontimecheckemail() {
    var em = document.getElementById('email').value;
    if (em.length <= 0) {
        document.getElementById("foremail").innerHTML="<font color='red'>邮件不能为空</font>";
    } else if (!ischeckemail(em)) {
        document.getElementById("foremail").innerHTML="<font color='red'>邮件格式不正确</font>";
    }else {
        document.getElementById("foremail").innerHTML="<font color='red'></font>";
    }
}


function registe() {
    var n = document.getElementById('name').value;
    var p = document.getElementById('password').value;
    var p2 = document.getElementById('check').value;
    var em = document.getElementById('email').value;
    var isSuccessful = false;
    if (n.length <= 0) {
        alert("用户名不能为空");
    }
    else if (p.length <= 0) {
        alert("密码不能为空");
    }
    else if (p != p2) {
        alert("密码不相等");
    }
    else if (em.length <= 0) {
        alert("邮件不能为空");
    } else if (!ischeckemail(em)) {
        alert("邮件格式不正确");
    }
    else if (!is_psd(p)) {
        alert("密码格式不正确");
    } else if (!is_user_name(n)) {
        alert("用户名不正确");
    } else if (n == p) {
        alert("密码不能与用户名相同");
    }
    else {
        alert("注册成功");
        isSuccessful = true;
    }
    if (isSuccessful) {
        document.cookie = "username=zyh";
    }
    if (isSuccessful) {
        document.getElementById('light').style.display = 'none';
        document.getElementById('fade').style.display = 'none';
        document.getElementById('nav1').style.display = 'block';
        document.getElementById('defaultnav').style.display = 'none'
    }

}

function login() {
    var n = document.getElementById('name2').value;
    var p = document.getElementById('password2').value;
    var isSuccessful = false;

    // var isOk = false;

    var checkCode = code.toUpperCase();
    var inputCode = document.getElementById("input").value.toUpperCase(); //取得输入的验证码并转化为大写

    if (n.length <= 0) {
        alert("请输入用户名");
    } else if (p.length <= 0) {
        alert("请输入密码");
    } else if (inputCode.length <= 0) { //若输入的验证码长度为0
        alert("请输入验证码！"); //则弹出请输入验证码
    } else if (n != "zyh") {
        alert("用户不存在");
    } else if (p != "zyh") {
        alert("密码错误");
    } else if (inputCode != checkCode) { //若输入的验证码与产生的验证码不一致时
        alert("验证码输入错误！@_@"); //则弹出验证码输入错误
        change();//刷新验证码
        document.getElementById("input").value = "";//清空文本框
    }
    else { //输入正确时
        alert("登陆成功");
        isSuccessful = true;
    }
    if (isSuccessful) {
        document.cookie = "username=zyh";
    }
    if (isSuccessful) {
        document.getElementById('nav1').style.display = 'block';
        document.getElementById('defaultnav').style.display = 'none';
        document.getElementById('login').style.display = 'none';
        document.getElementById('login2').style.display = 'none'
    }
}

function clickregiste() {
    document.getElementById('light').style.display = 'block';
    document.getElementById('fade').style.display = 'block'
}

function clicklogin() {
    document.getElementById('login').style.display = 'block';
    document.getElementById('login2').style.display = 'block'
}

function clicklogout() {
    document.cookie = "username=; expires=Thu, 01 Jan 1970 00:00:00 GMT ";
    document.getElementById('nav1').style.display = 'none';
    document.getElementById('defaultnav').style.display = 'block';
}

function cancelregiste() {
    document.getElementById('light').style.display = 'none';
    document.getElementById('fade').style.display = 'none';
}

function cancellogin() {
    document.getElementById('login').style.display = 'none';
    document.getElementById('login2').style.display = 'none'
}


var code; //在全局定义验证码

// //校验验证码
// function validate(){
//     var checkCode = code.toUpperCase();
//     var inputCode = document.getElementById("input").value.toUpperCase(); //取得输入的验证码并转化为大写
//     if(inputCode.length <= 0) { //若输入的验证码长度为0
//         alert("请输入验证码！"); //则弹出请输入验证码
//     }
//     else if(inputCode != checkCode ) { //若输入的验证码与产生的验证码不一致时
//         alert("验证码输入错误！@_@"); //则弹出验证码输入错误
//         change();//刷新验证码
//         document.getElementById("input").value = "";//清空文本框
//     }
//     else { //输入正确时
//         alert("^-^"); //弹出^-^
//     }
// }

function getCode(n) {
    var all = "azxcvbnmsdfghjklqwertyuiopZXCVBNMASDFGHJKLQWERTYUIOP0123456789";
    var b = "";
    for (var i = 0; i < n; i++) {
        var index = Math.floor(Math.random() * 62);
        b += all.charAt(index);

    }
    return b;
};

function change() {
    code = getCode(4);
    document.getElementById("check2").innerHTML = code;
}

// //设置此处的原因是每次进入界面展示一个随机的验证码，不设置则为空
// window.onload = change;

window.onload = checkcookies();

function is_user_name(userName) {
    var reg = /^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{8,16}$/;
    var isok = reg.test(userName);
    return isok;
}

function is_psd(password) {
    var reg = /^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{8,16}$/;
    var isok = reg.test(password);
    return isok;
}

function ischeckemail(email) {
    var reg = /^\w+((-\w+)|(\.\w+))*\@[A-Za-z0-9]+((\.|-)[A-Za-z0-9]+)*\.[A-Za-z0-9]+$/;
    var isok = reg.test(email);
    return isok;
}

function checkcookies() {
    var username = getCookie("username");
    if (username != "") {
        document.getElementById('nav1').style.display = 'block';
        document.getElementById('defaultnav').style.display = 'none';
    }
    else {
        document.getElementById('nav1').style.display = 'none';
        document.getElementById('defaultnav').style.display = 'block';
    }
}

function getCookie(cname) {
    var name = cname + "=";
    var ca = document.cookie.split(';');
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i].trim();
        if (c.indexOf(name) == 0) return c.substring(name.length, c.length);
    }
    return "";
}
