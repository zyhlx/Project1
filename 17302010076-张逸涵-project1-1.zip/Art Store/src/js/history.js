// function findCookies(){
//     var i;
//     var web = document.getElementById("historyWeb");
//     for(i=window.history.length;i>=0;i--){
//         var newWeb = document.createElement("span");
//         newWeb.style.display='inline-block';
//         newWeb.innerHTML = '<a style="display: inline-block" href="javascript:history.go(-'+(i-1)+')>'+
//     }
// }


function glog(evt) //定义纪录鼠标点击动作的函数
{
    evt = evt ? evt : window.event;
    var srcElem = (evt.target) ? evt.target : evt.srcElement;
    try {
        while (srcElem.parentNode && srcElem != srcElem.parentNode)
//以上这个语句判断鼠标动作是否发生在有效区域，防止用户的无效点击也被纪录下来
        {
            if (srcElem.tagName && srcElem.tagName.toUpperCase() == "A")//判断用户点击的对象是否属于链接
            {
                linkname = srcElem.innerHTML; //取出事件发生源的名称，也就是<a>和<a/>之间的文字，也就是链接名称哈
                address = srcElem.href + "_www.achome.cn_"; //取出事件发生源的href值，也就是该链接的地址
                wlink = linkname + "+" + address; //将链接名称和链接地址整合到一个变量当中
                old_info = getCookie4("history_info"); //从Cookies中取出以前纪录的浏览历史，该函数后面有声明
//以下程序开始判断新的浏览动作是否和已有的前6个历史重复，如果不重复则写入cookies
//                 var insert = true;
//                 if (old_info == null) //判断cookie是否为空
//                 {
//                     insert = true;
//                 }
//                 else {
//                     var old_link = old_info.split("_www.achome.cn_");
//                     for (var j = 0; j <= 5; j++) {
//                         if (old_link[j].indexOf(linkname) != -1)
//                             insert = false;
//                         if (old_link[j] == "null")
//                             break;
//                     }
//                 }
//                 if (insert) {
                    wlink += getCookie4("history_info");
                    setCookie4("history_info", wlink); //写入cookie，该函数后面有声明
                    history_show().reload();
                    break;
                // }
            }
            srcElem = srcElem.parentNode;
        }
    }
    catch (e) {
    }
    return true;
}

document.onclick = glog;//使每一次页面的点击动作都执行glog函数
//cookie的相关函数
//读取cookie中指定的内容
function getCookieVal(offset) {
    var endstr = document.cookie.indexOf(";", offset);
    if (endstr == -1) endstr = document.cookie.length;
    return unescape(document.cookie.substring(offset, endstr));
}

function getCookie4(name) {
    var arg = name + "=";
    var alen = arg.length;
    var clen = document.cookie.length;
    var i = 0;
    while (i < clen) {
        var j = i + alen;
        if (document.cookie.substring(i, j) == arg) return getCookieVal(j);
        i = document.cookie.indexOf(" ", i) + 1;
        if (i == 0) break;
    }
    return null;
}

//将浏览动作写入cookie
function setCookie4(name, value) {
    var exp = new Date();
    exp.setTime(exp.getTime() + 1000000);
    document.cookie = name + "=" + value + "; expires=" + exp.toGMTString();
}

function history_show() {
    var history_info = getCookie4("history_info"); //取出cookie中的历史记录
    var content = ""; //定义一个显示变量
    if (history_info != null) {
        history_arg = history_info.split("_www.achome.cn_");
        var i;
     a:{   for (i = 0; i <= 5; i++) {
            if (history_arg[i] != "null") {
                var wlink = history_arg[i].split("+");
                content += ("<font color='#ff000'>↑</font>" + "<a href='" + wlink[1] + "' target='_blank'>" + wlink[0] + "</a>");
            }else if(history_arg[i] == "null"){
                break a;
            }
            document.getElementById("history").innerHTML = content;
        }}
    }
    else {
        document.getElementById("history").innerHTML = "对不起，您没有任何浏览纪录";
    }
}