function searchCommodity(){
    document.cookie = "search="+document.getElementById("search").value;
    window.location.href="/Art%20Store/src/Art%20Store-Search%20page.html";
}
function searchArtist() {
    document.cookie="search="+document.getElementById("artist").innerText;
    window.location.href="/Art%20Store/src/Art%20Store-Search%20page.html";
}