function searchResult(){
    var content = getCookie("search")
    if (content !==""){
        document.getElementById("mainSearch").style.display="block";
        document.getElementById("noResult").style.display="none";
        document.getElementById("search").value = content;
    }else {
        document.getElementById("mainSearch").style.display="none";
        document.getElementById("noResult").style.display="block";
    }
    document.cookie = "search=; expires=Thu, 01 Jan 1970 00:00:00 GMT ";
}
window.onload=searchResult();

function searchResult2(){
    var content = document.getElementById("search").value;
    if (content !==""){
        document.getElementById("mainSearch").style.display="block";
        document.getElementById("noResult").style.display="none";
    }else {
        document.getElementById("mainSearch").style.display="none";
        document.getElementById("noResult").style.display="block";
    }
}

function getCookie(cname) {
    var name = cname + "=";
    var ca = document.cookie.split(';');
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i].trim();
        if (c.indexOf(name) == 0) return c.substring(name.length, c.length);
    }
    return "";
}