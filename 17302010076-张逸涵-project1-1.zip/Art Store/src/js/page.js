var whichPage = 1;
function turnOverPage1() {
    var num = document.getElementById('center1').innerHTML;
    if ((parseInt(num) >= 5) && (parseInt(num) <= 19)) {
        changePage2();
        document.getElementById('center1').previousElementSibling.innerHTML = num - 2;
        document.getElementById('center1').innerText = num - 1;
        document.getElementById('center1').nextElementSibling.innerHTML = num;
        whichPage=whichPage-1;
    }
    else if ((parseInt(num) <= 5)) {
        changePage1();
        whichPage=parseInt(num) - 1;
    }
}
function turnOverPage2() {
    var num = document.getElementById('center1').innerHTML;
    if ((parseInt(num)<=18)&&(parseInt(num)>=5)){
        changePage2();
        document.getElementById('center1').previousElementSibling.innerHTML=num;
        document.getElementById('center1').innerText=parseInt(num)+1;
        document.getElementById('center1').nextElementSibling.innerHTML=parseInt(num) + 2;
        whichPage = parseInt(num) + 1;
    }else if(parseInt(num)>=19) {
        changePage3();
        whichPage = whichPage +1;
    }

}
function changePage1() {
    document.getElementById("page2").style.display='none';
    document.getElementById("page1").style.display='block';
    document.getElementById("page3").style.display='none';
}
function changePage2() {
    document.getElementById("page1").style.display='none';
    document.getElementById("page2").style.display='block';
    document.getElementById("page3").style.display='none';
}
function changePage3() {
    document.getElementById("page1").style.display='none';
    document.getElementById("page2").style.display='none';
    document.getElementById("page3").style.display='block';
}
function back(number) {
    var num = number.innerHTML;
    if ((parseInt(num)<=19)&&(parseInt(num)>=5)){
    changePage2();
    document.getElementById('center1').previousElementSibling.innerHTML=num - 1;
    document.getElementById('center1').innerText=num;
    document.getElementById('center1').nextElementSibling.innerHTML=parseInt(num) + 1;
}else if(parseInt(num)>19){
        changePage3();
    }else if (parseInt(num)<=5){
        changePage1();
    }
    whichPage = parseInt(num);
}
function page1() {
    if ((whichPage<=5)&&(whichPage>1)){
        whichPage=whichPage - 1;
    }else if (whichPage>19&&whichPage<=23){
        whichPage=whichPage - 1;
    }else if (whichPage ===19){
        var n = document.getElementById("center1");
        n.innerText = 18;
        back(n);
        whichPage = 18;
    }
}
function page2() {
    if ((whichPage<5)&&(whichPage>=1)){
        whichPage=whichPage + 1;
    }else if (whichPage>=19&&whichPage<23){
        whichPage=whichPage + 1;
    }else if(whichPage === 5){
        var n = document.getElementById("center1");
        n.innerText = 6;
        back(n);
        whichPage = 6;
    }
}