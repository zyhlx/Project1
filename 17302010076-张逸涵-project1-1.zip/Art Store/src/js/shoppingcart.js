var isSuccessful = false;
checkcookies2("commodity");
var isdelete1 = false;
var isdelete2 = false;
var isdelete3 = false;
var commodity1 = getCookie("delete1");
var commodity2 = getCookie("delete2");
var commodity3 = getCookie("delete3");
if(commodity1 ===undefined){
    document.cookie="delete1=";
}
if(commodity2 ===undefined){
    document.cookie="delete2=";
}
if(commodity3 === undefined){
    document.cookie="delete3=";
}

function addnew() {
    var commodity = getCookie("commodity");
    add_shoppingcart();
    if(commodity3 !==""&&commodity3 !==undefined&&commodity ===""){
        isdelete3 = true;
        document.getElementById("goods3").parentElement.style.display = 'none';
        document.getElementById("goods3-2").parentElement.style.display='table';
    }
    if (commodity2 !==""&&commodity2 !==undefined){
        isdelete2 = true;
        document.getElementById("goods2").parentElement.style.display = 'none';
        document.getElementById("goods2-2").parentElement.style.display='table';
    }
    if (commodity1 !==""&&commodity1!==undefined){
        isdelete1 = true;
        document.getElementById("goods1").parentElement.style.display = 'none';
        document.getElementById("goods1-2").parentElement.style.display='table';
    }
    if (isdelete1 && isdelete2 && (isdelete3||!isSuccessful)) {
        document.getElementById("nocommodity").style.display = 'block';
        document.getElementById("container1").style.display = 'none';
        document.getElementById("goods1-2").parentElement.style.display='table';
    }
}


function add_shoppingcart() {
    // var goods3 = 'goods3'
    // //获取第1个td的内容(商品名)
    // var name = getCookie("commodity");
    // //获取第2个td的内容(单价)
    // var price = getCookie("price");
    // //作者
    // var artist = getCookie("artist");
    // //图片路径
    // var src = getCookie("src")
    //创建新的table,设置内容,追加到div下
    var newtable = document.createElement("table");
    // newtable.innerHTML = '<tbody id="' + goods3 + '"><tr><td rowspan="3"><img src=" ' + src + '" alt="' + name + '" width="150" height="150"></td><td class="name">' + name + '</td></tr><tr><td class="artist">' + artist + '</td></tr><tr><td class="final"><div><img src="images/icon/star_inactive_16_ns.png"height="16" width="16"alt="star">价格：<span>$' + price + '</span>\n' + '</div>\n' +
    //     '                <button onclick="drop(this)"><img src="images/icon/xfce_system_exit.png" width="16" height="14" alt="delete">删除</button>\n' +
    //     '            </td>\n' +
    //     '        </tr></tbody>'//添加删除事件
    //




    newtable.innerHTML='<tbody id="goods3">\n' +
        '            <tr>\n' +
        '                <td rowspan="3">\n' +
        '                    <a href="Art%20Store-Commodity%20details.html"><img src="images/works/mother-and-child-1922-1.jpg!Large.jpg" alt="motherandchild" height="150" width="150">\n' +
        '                </a></td>\n' +
        '                <td class="name">Mother and Child(Olga and Son)</td>\n' +
        '            </tr>\n' +
        '            <tr>\n' +
        '                <td class="artist">Pablo Picasso</td>\n' +
        '            </tr>\n' +
        '            <tr>\n' +
        '                <td class="final">\n' +
        '                    <div>\n' +
        '                        <img src="images/icon/star_inactive_16_ns.png" height="16" width="16"\n' +
        '                             alt="star">价格：<span>$100.0000</span>\n' +
        '                    </div>\n' +
        '                    <button onclick="drop(this)"><img src="images/icon/xfce_system_exit.png" width="16" height="14"\n' +
        '                                                      alt="delete">删除\n' +
        '                    </button>\n' +
        '                </td>\n' +
        '            </tr>\n' +
        '            </tbody>\n' ;
    var div = document.getElementById("mainpart");
    div.appendChild(newtable);
    if(!isSuccessful){
        newtable.style.display='none';
    }
}


function checkcookies2(name) {
    var cookiesneed = getCookie(name);
    if (cookiesneed != "") {
        isSuccessful = true;
    }
    else {
        isSuccessful = false;
    }
}

function getCookie(cname) {
    var name = cname + "=";
    var ca = document.cookie.split(';');
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i].trim();
        if (c.indexOf(name) == 0) return c.substring(name.length, c.length);
    }
    return "";
}

//删除table===================
function drop(btn) {
    var g = btn.parentElement.parentElement.parentElement.id;
    switch (g) {
        case "goods1": {
            exdate=new Date();
            isdelete1 = true;
            document.cookie = "delete1="+exdate.getMilliseconds();
            document.getElementById("goods1-2").parentElement.style.display='table';
            break;
        }
        case 'goods2': {
            exdate=new Date();
            isdelete2 = true;
            document.cookie = "delete2="+exdate.getMilliseconds();
            document.getElementById("goods2-2").parentElement.style.display='table';
            break;
        }
        case 'goods3': {
            exdate=new Date();
            isdelete3 = true;
            document.cookie = "delete3="+exdate.getMilliseconds();
            document.cookie = "commodity=; expires=Thu, 01 Jan 1970 00:00:00 GMT ";
            document.getElementById("goods3-2").parentElement.style.display='table';
            break;
        }
    }
    // var table = btn.parentNode.parentNode.parentNode.parentNode;
    // var div = document.getElementById("mainpart");
    var table = btn.parentElement.parentElement.parentElement.parentElement;
    table.style.display = 'none';
    //  div.removeChild(table);//不便于还原
    if (isdelete1 && isdelete2 && (isdelete3 || !isSuccessful)) {
        document.getElementById("nocommodity").style.display = 'block';
        document.getElementById("container1").style.display = 'none';
    }
}

//还原
function canceldelete() {

    if (isdelete1) {
        var table = document.getElementById('goods1').parentNode;
        table.style.display = 'table';
        isdelete1 = false;
        document.cookie = "delete1=; expires=Thu, 01 Jan 1970 00:00:00 GMT ";
        document.getElementById("nocommodity").style.display = 'none';
        document.getElementById("container1").style.display = 'block';
        document.getElementById("goods1-2").parentElement.style.display='none';
    }
    if (isdelete2) {
        var table = document.getElementById('goods2').parentNode;
        table.style.display = 'table';
        isdelete2 = false;
        document.cookie = "delete2=; expires=Thu, 01 Jan 1970 00:00:00 GMT ";
        document.getElementById("nocommodity").style.display = 'none';
        document.getElementById("container1").style.display = 'block';
        document.getElementById("goods2-2").parentElement.style.display='none';
    }
    if (isdelete3) {
        var table = document.getElementById('goods3').parentNode;
        table.style.display = 'table';
        isdelete3 = false;
        document.cookie = "delete3=; expires=Thu, 01 Jan 1970 00:00:00 GMT ";
        document.getElementById("nocommodity").style.display = 'none';
        document.getElementById("container1").style.display = 'block';
        document.getElementById("goods3-2").parentElement.style.display='none';
        document.cookie = "commodity=Mother and Child(Olga and Son)"
    }
}
function pay() {
    if (!(isdelete1 && isdelete2 && (isdelete3 || !isSuccessful))){
        alert('支付成功');
    }else {
        alert('还没有购买商品哦');
    }

}

window.onload = addnew();
function canceldelete2(btn) {
    var which =btn.parentElement.parentElement.parentElement;
    if(which.id.indexOf("goods1-2")!==-1){
        var table = document.getElementById('goods1').parentNode;
        table.style.display = 'table';
        isdelete1 = false;
        document.cookie = "delete1=; expires=Thu, 01 Jan 1970 00:00:00 GMT ";
        document.getElementById("nocommodity").style.display = 'none';
        document.getElementById("container1").style.display = 'block';
        which.parentElement.style.display='none';
    }
    if(which.id.indexOf("goods2-2")!==-1){
        var table = document.getElementById('goods2').parentNode;
        table.style.display = 'table';
        isdelete2 = false;
        document.cookie = "delete2=; expires=Thu, 01 Jan 1970 00:00:00 GMT ";
        document.getElementById("nocommodity").style.display = 'none';
        document.getElementById("container1").style.display = 'block';
        which.parentElement.style.display='none';
    }
    if (which.id.indexOf("goods3-2")!==-1) {
        var table = document.getElementById('goods3').parentNode;
        table.style.display = 'table';
        isdelete3 = false;
        document.cookie = "delete3=; expires=Thu, 01 Jan 1970 00:00:00 GMT "
        document.getElementById("nocommodity").style.display = 'none';
        document.getElementById("container1").style.display = 'block';
        document.cookie = "commodity=Mother and Child(Olga and Son)";
        which.parentElement.style.display='none';
    }

}

// function navshoppingcart() {
//     var commodity1 = getCookie("delete1");
//     var commodity2 = getCookie("delete2");
//     var commodity3 = getCookie("delete3");
//     var ul = document.getElementById("shopping-cart-box");
//     var iscommodity3 = checkcookies("commodity");
//     ul.innerHTML = "";
//     if(commodity1 == ""){
//         var newli1 = document.createElement("li");
//         newli1.innerHTML = '<p><span>Still Life with Bowl and Fruit</span><br><span>$120.0000</span></p>';
//         ul.appendChild(newli1);
//     }
//     if(commodity2 == ""){
//         var newli2 = document.createElement("li");
//         newli2.innerHTML = '<p><span>Family of Sanltimbanques</span><br><span>$170.0000</span></p>';
//         ul.appendChild(newli2);
//     }
//     if((commodity3 == "")&&(iscommodity3 !==undefined)){
//         var newli3 = document.createElement("li");
//         newli3.innerHTML = '<p><span>Mother and Child(Olga and Son)</span><br><span>$100.0000</span></p>'
//         ul.appendChild(newli3);
//     }
//     if ((commodity1!="")&&(commodity2 !="")&&(commodity3 !="")&&(iscommodity3 ===undefined)){
//         var newli4 = document.createElement("li");
//         newli4.innerHTML = '<p>还什么都没有哦~</p>';
//         ul.appendChild(newli4);
//     }
// }
//
// function getCookie(cname) {
//     var name = cname + "=";
//     var ca = document.cookie.split(';');
//     for (var i = 0; i < ca.length; i++) {
//         var c = ca[i].trim();
//         if (c.indexOf(name) == 0) return c.substring(name.length, c.length);
//     }
//     return "";
// }