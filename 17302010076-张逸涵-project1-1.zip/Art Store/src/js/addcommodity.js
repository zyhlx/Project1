var works = new Array();

var isSuccessful = false;

function adding_shoppingcart() {
    var work = new Object();
    work.name = document.getElementById("title").innerText;
    work.price = document.getElementById("price").innerText;
    work.artist = document.getElementById("artist").innerText;
    work.picture_src = document.getElementById("image").src;
    work.date = Date();
    var isExist = false;
    checkcookies1("username");
    if (isSuccessful) {
        // for (var j = 0; j < works.length; j++) {
        //     if (works[j].name == work.name) {
        //         alert("已经添加");
        //         isExist = true;
        //         break;
        //     }
        // }
        var cookiesneed = getCookie("commodity");
        if (cookiesneed === ""||cookiesneed===undefined) {
            isExist = false;
            document.cookie="delete3=";
        }
        else {
            isExist = true;
            alert("已经添加");
        }
    }else {
        alert("请先登录");
    }
    if (!isExist&&isSuccessful) {
        works[works.length] = work;
        alert("添加成功");
        document.cookie = "commodity=" + work.name;
        // document.cookie = "artist=" + work.artist;
        // document.cookie = "src=" + work.picture_src;
        // document.cookie = "price=" + work.price;
    }
}


function checkcookies1(name) {
    var cookiesneed = getCookie(name);
    if (cookiesneed != "") {
        isSuccessful = true;
    }
    else {
        isSuccessful = false;
    }
}

function getCookie(cname) {
    var name = cname + "=";
    var ca = document.cookie.split(';');
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i].trim();
        if (c.indexOf(name) == 0) return c.substring(name.length, c.length);
    }
    return "";
}