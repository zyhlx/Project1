window.onload = function () {
    var imgNode = document.getElementById("demo");
    var xSpan = document.getElementById("x");
    var ySpan = document.getElementById("y");
    imgNode.onmousemove = function () {
        xSpan.innerHTML = event.clientX;
        ySpan.innerHTML = event.clientY;
        if (event.clientX < demo.offsetWidth / 2 - 10) {
            if (MyMar) clearInterval(MyMar);
            Fang = 1;
            MyMar = setInterval(MarqueeL, speed)
        }
        else if (event.clientX > demo.offsetWidth / 2 - 10 && event.clientX < demo.offsetWidth / 2 + 10) {
            clearInterval(MyMar)
        }
        else if (event.clientX > demo.offsetWidth / 2 + 10) {
            if (MyMar) clearInterval(MyMar);
            Fang = 0;
            MyMar = setInterval(MarqueeR, speed)
        }
    }
}



var speed = 15;
var c1_w = c1.offsetWidth;
c1.style.width = c1_w * 3 + "px";
c1.innerHTML = c1.innerHTML;
var Fang = 1;
var MyMar = setInterval(MarqueeL, speed);

function MarqueeL()// 下层div向左滚动
{
    if (c1_w - demo.scrollLeft * 1 <= 0) demo.scrollLeft -= c1_w; else demo.scrollLeft++;
}

function MarqueeR()//下层div向右滚动
{
    if (c1_w - demo.scrollLeft >= c1_w) demo.scrollLeft += c1_w / 1; else demo.scrollLeft--;
}