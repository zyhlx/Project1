function fnGo(obj) {
    obj.setAttribute("href", "http://www.163.com/");
}
